#!/usr/bin/env bash

python app/views.py